from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def getMenu():
  return 'Success'

# uvicorn main:app --reload