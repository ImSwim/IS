# pip install fastapi
# pip install pydantic
# pip install SQLAlchemy
# pip install mysql
# 출처: https://jongsky.tistory.com/17

from fastapi import FastAPI
from pydantic import BaseModel
from dbconnection import engineconn
from model import Test
import uvicorn

##### DB test
app = FastAPI() # FastAPI 모듈

@app.get("/")
def index():
    return {
        "Python": "Framework",
    }

engine = engineconn()
session = engine.sessionmaker()


class Item(BaseModel):
    name : str
    number : int

@app.get("/dbtest")
async def first_get():
    example = session.query(Test).all()
    return example

##########

# @app.get("/booth")
# async def get_booth(booth : db.booth):
#   return booth

# @app.get("/booth/{booth_id}/menu")
